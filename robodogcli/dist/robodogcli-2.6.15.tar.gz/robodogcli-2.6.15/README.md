# file: README.md
# Robodog Code
![Robodog MCP File Service](screenshot-mcp.png)

## Overview  
Robodog Code is a lightweight, zero-install, fast, command-line style generative AI client that integrates multiple providers (OpenAI, OpenRouter, LlamaAI, DeepSeek, Anthropic, Sarvam AI, Google Search API, and more) into a unified interface. Key capabilities include:

NEVER TRUST A CODE SPEWING ROBOT!

- Access to cutting-edge models: `o4-mini` (200k context), `gpt-4`, `gpt-4-turbo`, `dall-e-3`, Llama3-70b, Claude Opus/Sonnet, Mistral, Sarvam-M, Gemma 3n, etc.  
- Massive context windows (up to 200k tokens) across different models.  
- Seamless chat history & knowledge management with stashes and snapshots.  
- File import/export (text, Markdown, code, PDF, images via OCR).  
- In-chat file inclusion from a local MCP server.  
- Built-in web search integration.  
- Image generation & OCR pipelines.  
- Limit scope of the context window using filter tagging pattern=*robodog*.py recursive
- AI-driven web automation/testing via Playwright (`/play`).  
- Raw MCP operations (`/mcp`).  
- `/todo` feature: automate and track tasks defined in `todo.md`.  
- Accessible, retro “console” UI with customizable themes and responsive design.  

---

## Try Robodog  

- **Web**: https://adourish.github.io/robodog/robodog/dist/  
- **Android**: https://play.google.com/store/apps/details?id=com.unclebulgaria.robodog  
- **npm packages**:  
  - `npm install robodoglib`  
  - `npm install robodogcli`  
  - `npm install robodog`  
- **Python**:  
  - `pip install robodogcli`  
  - `pip show -f robodogcli`  
  - `python -m robodogcli.cli --help`  
  - `pip install --upgrade requests tiktoken PyYAML openai playwright pydantic langchain` (optional)  

---

## Configuration  

Click the ⚙️ icon in the top-menu to open settings, or edit your YAML directly:

```yaml
configs:
  providers:
    - provider: openAI
      baseUrl: "https://api.openai.com"
      apiKey: "<open ai token>"
      httpReferer: "https://adourish.github.io"
    - provider: openRouter
      baseUrl: "https://openrouter.ai/api/v1"
      apiKey: "<open router token>"
      httpReferer: "https://adourish.github.io"
    - provider: searchAPI
      baseUrl: "https://google-search74.p.rapidapi.com"
      apiKey: "<search token>"
      httpReferer: "https://adourish.github.io"
  
  mcpServer:
    baseUrl: "http://localhost:2500"  
    apiKey:   "testtoken"  

  specialists:
    - specialist: nlp
      resume: natural language processing, chatbots, content generation, language translation
    - specialist: gi
      resume: generates images from textual descriptions. understanding and interpreting textual descriptions 
    - specialist: search
      resume: generate simple search results

  models:
    - provider: openRouter
      model: openai/gpt-5-mini
      stream: true
      specialist: nlp
      about: "Best for performance. Context window: 1.05M tokens. Competitive in Academia (#2), Marketing/Seo (#3), Health (#4), Legal (#4), Science (#4)."
    - provider: openRouter
      model: GPT-4o-mini
      stream: true
      specialist: nlp
      about: "Best for most questions. Context window: 1.05M tokens. Pricing: $0.40/M input, $1.60/M output."
    - provider: openAI
      model: o4-mini
      stream: true
      specialist: nlp
      about: "Biggest model with 200k context window and world view. Best for critical thinking. Context window: 200K tokens."
    - provider: openAI
      model: o1
      stream: true
      specialist: nlp
      about: "Big model with 128k context window and small world view. Good for critical thinking. Context window: 128K tokens."
    - provider: openRouter
      model: openai/o4-mini
      stream: true
      specialist: nlp
      about: "Best for big content. Context window: 200K tokens."
    - provider: openRouter
      model: deepseek/deepseek-r1
      stream: true
      specialist: nlp
      about: "Best for summarizing. Context window: 128K tokens. Model size: 671B parameters (37B active). Performance: #2 in Roleplay, #6 in Translation, #9 in Programming, #10 in Science. Supports thinking and non-thinking modes."
    - provider: openRouter
      model: google/gemini-2.5-pro
      stream: true
      specialist: nlp
      about: "Best for speed. Context window: 1.05M tokens. Performance: #3 in Health, #5 in Marketing, Roleplay, Academia, Science. Advanced reasoning, coding, mathematics, scientific tasks. Pricing: $1.25/M input, $10/M output."
    - provider: openRouter
      model: qwen/qwen3-coder
      stream: true
      specialist: nlp
      about: "Best for large docs when speed is not an issue. Context window: 262K tokens. Model size: 480B parameters (35B active). Optimized for agentic coding tasks. Performance: #3 in Programming, #7 in Technology, #8 in Science. Pricing: $0.20/M input, $0.80/M output."
    - provider: openRouter
      model: anthropic/claude-sonnet-4
      stream: false
      specialist: gi
      about: "Best for creating images."
    - provider: openRouter
      model: x-ai/grok-code-fast-1
      stream: false
      specialist: search
      about: "Best for searching. Context window: 256K tokens. Performance: #1 in Programming, #3 in Technology, #6 in Marketing/Seo, #10 in Trivia. Speedy and economical reasoning model. Pricing: $0.20/M input, $1.50/M output."
    - provider: searchAPI
      model: search
      stream: false
      specialist: search
      about: "Best for searching. Context window: 256K tokens. Performance: #1 in Programming, #3 in Technology, #6 in Marketing/Seo, #10 in Trivia. Speedy and economical reasoning model. Pricing: $0.20/M input, $1.50/M output."

```

---

## Supported Models  

### OpenAI  
- gpt-4, gpt-4-turbo, gpt-3.5-turbo, gpt-3.5-turbo-16k, o4-mini, o1  
- dall-e-3  

### Others  
- LlamaAI: llama3-70b  
- Anthropic: Claude Opus 4, Claude Sonnet 4  
- DeepSeek R1  
- Mistral Medium 3, Devstral-Small  
- Sarvam-M  
- Google Gemma 3n E4B  

---

## Key Features  

- **Multi-Provider Support**: Switch between any configured provider or model on the fly (`/model`).  
- **Chat & Knowledge**: Separate panes for Chat History (💭) and Knowledge (📝)—both resizable.  
- **Stash Management**:  
  - `/stash <name>` — save current chat+knowledge  
  - `/pop <name>`   — restore a stash  
  - `/list`         — list all stashes  
- **File Import/Export**:  
  - `/import <glob>` — import files (.md, .js, .py, .pdf, images via OCR)  
  - `/export <file>` — export chat+knowledge snapshot  
- **MCP File Inclusion**:  
  - `/include all`  
  - `/include file=README.md`  
  - `/include pattern=*.js|*.css recursive`  
  - `/include dir=src pattern=*.py recursive`  
- **Raw MCP Operations**:  
  - `/mcp OP [JSON]` — e.g. `/mcp LIST_FILES`, `/mcp READ_FILE {"path":"./foo.py"}`  
- **Web Fetch & Automation**:  
  - `/curl [--no-headless] <url> [<url2>|<js>]` — fetch pages or run JS  
  - `/play <instructions>` — run AI-driven Playwright tests end-to-end  
- **Web Search**:  
  - Use `search` model or click 🔎 to perform live web queries.  
- **Image Generation & OCR**: Ask questions to `dall-e-3` or drop an image to extract text via OCR.  
- **Interactive Console UI**: Retro “pip-boy green” theme, responsive on desktop/mobile, accessible.  
- **Performance & Size Indicators**: Emoji feedback for processing speed and token usage.  
- **Extensive Command Palette**: `/help` lists all commands, indicators, and settings.  
- **Todo Automation**: Use `/todo` to execute tasks defined in `todo.md` across your project roots.  

---

## Usage Examples  

### 1) AI-Driven Web Tests with `/play`
```
/play navigate to https://example.com, extract the page title, and verify it contains 'Example Domain'
```

### 2) Fetch & Scrape with `/curl`
```
/curl https://example.com
```

### 3) Include Local Files via MCP
```
/include pattern=*.js recursive fix bug in parser
```

### 4) Raw MCP Commands
```
/mcp LIST_FILES
/mcp READ_FILE {"path":"./src/cli.py"}
```

### 5) Switch Model on the Fly
```
/model o4-mini
```

### 6) Import & Export
```
/import **/*.md
/export conversation_snapshot.txt
```

---

## /todo Feature  

Robodog’s `/todo` command scans one or more `todo.md` files in your configured project roots, detects tasks marked `[ ]`, transitions them to `[~]` (Doing) when started, and `[x]` (Done) when completed. Each task may include:

- `include:` pattern or file specification to gather relevant knowledge
- `focus:` file path where the AI will write or update content
- Optional code fences below the task as initial context

You can have multiple `todo.md` files anywhere under your roots. `/todo` processes the earliest outstanding task, runs the AI with gathered knowledge, updates the focus file, stamps start/completion times, and advances to the next.

![Robodog MCP File Service](screenshot-todo.png)

### Example `todo.md` File Formats

```markdown
# file: project1/todo.md
- [ ] Revise API client
  - include: pattern=api/*.js recursive
  - focus: file=api/client.js
```knowledge
// existing stub
```


```markdown
- [ ] Add unit tests
  - include: file=tests/template.spec.js
  - focus: file=tests/api.client.spec.js
```

```markdown
# file: project2/docs/todo.md
- [ ] Update README
  - focus: file=README.md
- [ ] Generate changelog
  - include: pattern=CHANGELOG*.md
  - focus: file=CHANGELOG.md
```knowledge

```

```markdown
# todo readme
- [x] readme
  - include: pattern=*robodog*.md|*robodog*.py|*todo.md   recursive`
  - focus: file=c:\projects\robodog\robodogcli\temp\service.log
```knowledge
1. do not remove any content
2. add a new readme section for the /todo feature with examples of the todo.md files and how you can have as many as possible
3. give lots of exampkes of file formats
```


```markdown
# watch
- [ ] change app prints in service logger.INFO
  - include: pattern=*robodog*.md|*robodog*.py  recursive`
  - focus:   file=c:\projects\robodog\robodogcli\robodog\service.py
```knowledge
do not remove any features.
give me full drop in code file
```


```markdown
# fix logging
- [ ] ask: fix logging. change logging so that it gets log level through command line. change logger so that it takes log level from the command line param
  - include: pattern=*robodog*.md|*robodog*.py  recursive`
  - focus: file=c:\projects\robodog\robodogcli\robodog\cli3.py
```knowledge
my knowledge
```

You can chain as many tasks and files as needed. Each can reside in different directories, and Robodog will locate all `todo.md` files automatically.

## Configuration & Command Reference  

See command palette in-app (`/help`) or the reference below:

```
/help             — show help  
/models           — list configured models  
/model <name>     — switch model  
/key <prov> <key> — set API key  
/import <glob>    — import files into knowledge  
/export <file>    — export snapshot  
/clear            — clear chat & knowledge  
/stash <name>     — stash state  
/pop <name>       — restore stash  
/list             — list stashes  
/temperature <n>  — set temperature  
/top_p <n>        — set top_p  
/max_tokens <n>   — set max_tokens  
/frequency_penalty <n> — set frequency_penalty  
/presence_penalty <n>  — set presence_penalty  
/stream           — enable streaming mode  
/rest             — disable streaming mode  
/folders <dirs>   — set MCP roots  
/include …        — include files via MCP  
/curl …           — fetch pages / run JS  
/play …           — AI-driven Playwright tests  
/mcp …            — invoke raw MCP operation  
/todo             — run next To Do task  
```

---

## Build & Run  

```bash
# Clone or unzip robodog
cd robodog
python build.py
open ./dist/robodog.html
```

```bash
npm install robodoglib  
npm install robodogcli  
npm install robodog  
pip install robodogcli  
pip show -f robodogcli  
python -m robodogcli.cli --help  
python -m playwright install
```

---

Enjoy Robodog AI—the future of fast, contextual, and extensible AI interaction!