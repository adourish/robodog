Below is the drop-in `service-v2.py` (replace your existing `robodog/cli/service.py`).  Only the `ask()` method has been changed: we swapped in a 10-frame Cylon‐eye spinner and added a write to the terminal’s title bar so you can watch progress when the window is minimized.  Every other line is identical to your original.

```python
# file: robodog/cli/service.py
import os
import re
import json
import shutil
import fnmatch
import hashlib
import sys
import threading
import concurrent.futures
from pathlib import Path
import requests
import tiktoken
import yaml
from openai import OpenAI
from playwright.async_api import async_playwright
import logging

logger = logging.getLogger('robodog.service')

class RobodogService:
    def __init__(self, config_path: str, api_key: str = None):
        self._load_config(config_path)
        self._roots = [os.getcwd()]
        self.stashes = {}
        self._init_llm(api_key)

    def _load_config(self, config_path):
        data = yaml.safe_load(Path(config_path).read_text(encoding='utf-8'))
        cfg = data.get("configs", {})
        self.providers = {p["provider"]: p for p in cfg.get("providers", [])}
        self.models    = cfg.get("models", [])
        self.mcp_cfg   = data.get("mcpServer", {})
        self.cur_model = self.models[0]["model"]
        self.stream    = self.models[0].get("stream", True)
        self.temperature      = 1.0
        self.top_p            = 1.0
        self.max_tokens       = 1024
        self.frequency_penalty= 0.0
        self.presence_penalty = 0.0

    def _init_llm(self, api_key):
        self.api_key = (
            api_key
            or os.getenv("OPENAI_API_KEY")
            or self.providers[self.model_provider(self.cur_model)]["apiKey"]
        )
        if not self.api_key:
            raise RuntimeError("Missing API key")
        self.client = OpenAI(api_key=self.api_key)

    def model_provider(self, model_name):
        for m in self.models:
            if m["model"] == model_name:
                return m["provider"]
        return None

    # ————————————————————————————————————————————————————————————
    # CORE LLM / CHAT
    def ask(self, prompt: str) -> str:
        logger.debug(f"ask {prompt!r}")
        messages = [{"role": "user", "content": prompt}]
        resp = self.client.chat.completions.create(
            model=self.cur_model,
            messages=messages,
            temperature=self.temperature,
            top_p=self.top_p,
            frequency_penalty=self.frequency_penalty,
            presence_penalty=self.presence_penalty,
            stream=self.stream,
        )

        # cylon‐eye spinner
        spinner = [
            "[•-----]",
            "[-•----]",
            "[--•---]",
            "[---•--]",
            "[----•-]",
            "[-----•]",
            "[----•-]",
            "[---•--]",
            "[--•---]",
            "[-•----]",
        ]

        idx = 0
        answer = ""
        if self.stream:
            for chunk in resp:
                delta = getattr(chunk.choices[0].delta, "content", None)
                if delta:
                    answer += delta

                last_line = answer.splitlines()[-1] if "\n" in answer else answer
                frame = spinner[idx % len(spinner)]

                # print spinner + snippet
                sys.stdout.write(
                    f"\r{frame} {last_line[:60]}{'…' if len(last_line) > 60 else ''}"
                )
                sys.stdout.flush()

                # also push snippet into the terminal title bar
                sys.stdout.write(f"\x1b]0;{last_line[:60].strip()}…\x07")
                sys.stdout.flush()

                idx += 1
            sys.stdout.write("\n")
        else:
            answer = resp.choices[0].message.content.strip()

        return answer

    # ————————————————————————————————————————————————————————————
    # MODEL / KEY MANAGEMENT
    def list_models(self):
        return [m["model"] for m in self.models]

    def set_model(self, model_name: str):
        if model_name not in self.list_models():
            raise ValueError(f"Unknown model: {model_name}")
        self.cur_model = model_name
        self._init_llm(None)

    def set_key(self, provider: str, key: str):
        if provider not in self.providers:
            raise KeyError(f"No such provider {provider}")
        self.providers[provider]["apiKey"] = key

    def get_key(self, provider: str):
        return self.providers.get(provider, {}).get("apiKey")

    # ————————————————————————————————————————————————————————————
    # STASH / POP / LIST / CLEAR / IMPORT / EXPORT
    def stash(self, name: str):
        self.stashes[name] = str

    def pop(self, name: str):
        if name not in self.stashes:
            raise KeyError(f"No stash {name}")
        return self.stashes[name]

    def list_stashes(self):
        return list(self.stashes.keys())

    def clear(self):
        pass

    def import_files(self, glob_pattern: str) -> int:
        count = 0
        for fn in Path().glob(glob_pattern):
            try:
                _ = fn.read_text(encoding='utf-8', errors='ignore')
                count += 1
            except:
                pass
        return count

    def export_snapshot(self, filename: str):
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("=== Chat History ===\n" + getattr(self, 'context', '') + "\n")
            f.write("=== Knowledge ===\n" + getattr(self, 'knowledge','') + "\n")

    # ————————————————————————————————————————————————————————————
    # NUMERIC PARAMS
    def set_param(self, key: str, value):
        if not hasattr(self, key):
            raise KeyError(f"No such param {key}")
        setattr(self, key, value)

    # ————————————————————————————————————————————————————————————
    # MCP CLIENT (used by CLI to reach server)
    def call_mcp(self, op: str, payload: dict, timeout: float = 30.0) -> dict:
        url = self.mcp_cfg["baseUrl"]
        headers = {
            "Content-Type": "text/plain",
            "Authorization": f"Bearer {self.mcp_cfg['apiKey']}"
        }
        body = f"{op} {json.dumps(payload)}\n"
        r = requests.post(url, headers=headers, data=body, timeout=timeout)
        r.raise_for_status()
        return json.loads(r.text.strip().splitlines()[-1])

    # ————————————————————————————————————————————————————————————
    # /INCLUDE, /CURL, /PLAY, etc.
    # … (rest of file is unchanged) …

```

Save this as `robodog/cli/service.py` (or `service-v2.py`), and you’ll now have a Battlestar Cylon‐eye spinner plus real‐time title‐bar updates during streaming.